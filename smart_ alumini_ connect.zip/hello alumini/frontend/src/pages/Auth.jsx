import React, { useState } from 'react'
import axios from 'axios'
import { useApp } from '../context/AppContext.jsx'

export default function Auth() {
  const { setUser } = useApp()
  const [tab, setTab] = useState('login')
  const [err, setErr] = useState('')
  const [ok, setOk] = useState('')
  const [loading, setLoading] = useState(false)

  // Login
  const [lEmail, setLEmail] = useState('')
  const [lPass, setLPass] = useState('')

  // Signup
  const [sName, setSName] = useState('')
  const [sEmail, setSEmail] = useState('')
  const [sPass, setSPass] = useState('')
  const [sRole, setSRole] = useState('student')
  const [sCollege, setSCollege] = useState('')
  const [sDeg, setSDeg] = useState('')
  const [sGrad, setSGrad] = useState('')
  const [sMajor, setSMajor] = useState('')
  const [sCompany, setSCompany] = useState('')
  const [sRoleT, setSRoleT] = useState('')
  const [sExp, setSExp] = useState('')

  const emailOk = e => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)

  async function doLogin(e) {
    e?.preventDefault()
    setErr('')
    if (!lEmail.trim()) return setErr('Please enter your email address.')
    if (!emailOk(lEmail)) return setErr('Please enter a valid email (e.g. name@gmail.com).')
    if (!lPass) return setErr('Please enter your password.')
    setLoading(true)
    try {
      const r = await axios.post('/api/auth/login', { email: lEmail.trim(), password: lPass })
      setUser(r.data)
    } catch (ex) {
      setErr(ex.response?.data?.detail || 'Login failed.')
    }
    setLoading(false)
  }

  async function doSignup(e) {
    e?.preventDefault()
    setErr(''); setOk('')
    if (!sName.trim()) return setErr('Please enter your full name.')
    if (!sEmail.trim()) return setErr('Please enter your email address.')
    if (!emailOk(sEmail)) return setErr('Please enter a valid email (e.g. name@gmail.com).')
    if (!sCollege.trim()) return setErr('Please enter your college / university name.')
    if (sPass.length < 6) return setErr('Password must be at least 6 characters.')
    setLoading(true)
    try {
      const r = await axios.post('/api/auth/signup', {
        name: sName.trim(), email: sEmail.trim(), password: sPass,
        role: sRole, college: sCollege.trim(),
        degree: sDeg, gradYear: sGrad, major: sMajor,
        currentCompany: sCompany, currentRole: sRoleT, experience: sExp
      })
      setOk(`Welcome, ${r.data.name}! 🎉`)
      setTimeout(() => setUser(r.data), 700)
    } catch (ex) {
      setErr(ex.response?.data?.detail || 'Signup failed.')
    }
    setLoading(false)
  }

  const inp = (val, set, type = 'text', ph = '') => (
    <input type={type} value={val} onChange={e => set(e.target.value)} placeholder={ph} />
  )

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg)', padding: 20, overflowY: 'auto' }}>
      <div style={{ width: '100%', maxWidth: 440 }}>

        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 22 }}>
          <div style={{ width: 50, height: 50, background: 'linear-gradient(135deg,#6366f1,#8b5cf6)', borderRadius: 13, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Syne', fontWeight: 800, fontSize: 20, color: '#fff', marginBottom: 10 }}>A</div>
          <div style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: 22, color: 'var(--t)' }}>AlumniConnect + HVS.Ai</div>
          <div style={{ color: 'var(--t2)', fontSize: 13, marginTop: 3 }}>Connect with alumni from your college</div>
        </div>

        <div className="card">
          {/* Tabs */}
          <div style={{ display: 'flex', gap: 4, background: 'var(--bg3)', borderRadius: 9, padding: 4, marginBottom: 18 }}>
            {[['login','Sign In'],['signup','Sign Up']].map(([t, l]) => (
              <button key={t} onClick={() => { setTab(t); setErr(''); setOk('') }}
                style={{ flex: 1, padding: 8, borderRadius: 7, fontSize: 13, fontWeight: 600, border: 'none', cursor: 'pointer', fontFamily: 'DM Sans', background: tab === t ? 'var(--ac)' : 'transparent', color: tab === t ? '#fff' : 'var(--t2)' }}>
                {l}
              </button>
            ))}
          </div>

          {err && <div style={{ background: 'rgba(239,68,68,.1)', border: '1px solid rgba(239,68,68,.3)', borderRadius: 9, padding: '10px 13px', fontSize: 13, color: '#f87171', marginBottom: 13 }}>{err}</div>}
          {ok  && <div style={{ background: 'rgba(16,185,129,.1)',  border: '1px solid rgba(16,185,129,.3)',  borderRadius: 9, padding: '10px 13px', fontSize: 13, color: '#34d399', marginBottom: 13 }}>{ok}</div>}

          {/* Login */}
          {tab === 'login' && (
            <form onSubmit={doLogin} noValidate>
              <label className="lbl">Email Address</label>
              {inp(lEmail, setLEmail, 'email', 'e.g. name@gmail.com')}
              <label className="lbl">Password</label>
              {inp(lPass, setLPass, 'password', 'your password')}
              <button type="submit" className="btn btn-p" style={{ width: '100%', marginTop: 16 }} disabled={loading}>
                {loading ? 'Signing in...' : 'Sign In →'}
              </button>
              <p style={{ textAlign: 'center', fontSize: 12, color: 'var(--t3)', marginTop: 11 }}>
                New here? <strong style={{ color: 'var(--ac)', cursor: 'pointer' }} onClick={() => setTab('signup')}>Create account</strong>
              </p>
            </form>
          )}

          {/* Signup */}
          {tab === 'signup' && (
            <form onSubmit={doSignup} noValidate>
              <label className="lbl">Full Name *</label>{inp(sName, setSName, 'text', 'Your full name')}
              <label className="lbl">Email *</label>{inp(sEmail, setSEmail, 'email', 'e.g. name@gmail.com')}
              <label className="lbl">I am a...</label>
              <select value={sRole} onChange={e => setSRole(e.target.value)}>
                <option value="student">Student — looking for mentors</option>
                <option value="alumni">Alumni / Mentor — giving back</option>
              </select>
              <label className="lbl">College / University *</label>{inp(sCollege, setSCollege, 'text', 'e.g. IIT Bombay, MIT, Harvard')}

              {sRole === 'student' ? (
                <>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 12 }}>
                    <div><label className="lbl" style={{ marginTop: 0 }}>Degree</label>{inp(sDeg, setSDeg, 'text', 'e.g. B.Tech CS')}</div>
                    <div><label className="lbl" style={{ marginTop: 0 }}>Grad Year</label>{inp(sGrad, setSGrad, 'text', '2026')}</div>
                  </div>
                  <label className="lbl">Major / Field</label>{inp(sMajor, setSMajor, 'text', 'e.g. Computer Science')}
                </>
              ) : (
                <>
                  <label className="lbl">Current Company</label>{inp(sCompany, setSCompany, 'text', 'e.g. Google, TCS')}
                  <label className="lbl">Current Role</label>{inp(sRoleT, setSRoleT, 'text', 'e.g. Senior Software Engineer')}
                  <label className="lbl">Years of Experience</label>{inp(sExp, setSExp, 'text', 'e.g. 6 years')}
                </>
              )}

              <label className="lbl">Password * (min 6 chars)</label>{inp(sPass, setSPass, 'password', 'create a strong password')}
              <button type="submit" className="btn btn-p" style={{ width: '100%', marginTop: 16 }} disabled={loading}>
                {loading ? 'Creating...' : 'Create Account →'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
