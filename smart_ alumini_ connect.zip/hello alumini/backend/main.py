"""
AlumniConnect + HVS.Ai — FastAPI Backend
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import hashlib, time, random, string

app = FastAPI(title="AlumniConnect API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── In-memory database ────────────────────────────────────────────────────────
DB = {
    "users": {},
    "connections": [],
    "requests": [],
    "jobs": [],
    "events": [],
    "forum": [],
    "skills": {},
    "chats": {},
}

def rid():
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))

def hpw(p: str) -> str:
    return hashlib.sha256(p.encode()).hexdigest()[:16]

def norm(c: str) -> str:
    import re
    return re.sub(r'[^a-z0-9]', '', (c or '').strip().lower())

def safe(u: dict) -> dict:
    return {k: v for k, v in u.items() if k != '_pw'}

def my_conns(uid: str) -> List[str]:
    u = DB["users"].get(uid)
    if not u: return []
    uc = norm(u.get("college", ""))
    out = []
    for c in DB["connections"]:
        other = c["b"] if c["a"] == uid else (c["a"] if c["b"] == uid else None)
        if other:
            ou = DB["users"].get(other)
            if ou and norm(ou.get("college", "")) == uc:
                out.append(other)
    return out

# ── Auth ──────────────────────────────────────────────────────────────────────
class SignupData(BaseModel):
    name: str; email: str; password: str; role: str; college: str
    degree: Optional[str] = ""; gradYear: Optional[str] = ""; major: Optional[str] = ""
    currentCompany: Optional[str] = ""; currentRole: Optional[str] = ""; experience: Optional[str] = ""

class LoginData(BaseModel):
    email: str; password: str

@app.post("/api/auth/signup")
def signup(d: SignupData):
    e = d.email.lower().strip()
    if not e or "@" not in e: raise HTTPException(400, "Please enter a valid email address.")
    if DB["users"].get(e): raise HTTPException(400, "An account with this email already exists. Please sign in.")
    if not d.name.strip(): raise HTTPException(400, "Please enter your full name.")
    if not d.college.strip(): raise HTTPException(400, "Please enter your college / university name.")
    if len(d.password) < 6: raise HTTPException(400, "Password must be at least 6 characters.")
    u = {"uid": e, "email": e, "name": d.name.strip(), "role": d.role, "college": d.college.strip(),
         "pts": 0, "bio": "", "skills": [], "createdAt": int(time.time()), "_pw": hpw(d.password),
         "degree": d.degree, "gradYear": d.gradYear, "major": d.major,
         "currentCompany": d.currentCompany, "currentRole": d.currentRole,
         "experience": d.experience, "linkedin": "", "github": "", "interests": d.major or ""}
    DB["users"][e] = u
    return safe(u)

@app.post("/api/auth/login")
def login(d: LoginData):
    e = d.email.lower().strip()
    if not e: raise HTTPException(400, "Please enter your email address.")
    if not d.password: raise HTTPException(400, "Please enter your password.")
    u = DB["users"].get(e)
    if not u: raise HTTPException(401, "No account found with this email. Please sign up first.")
    if u["_pw"] != hpw(d.password): raise HTTPException(401, "Incorrect password. Please try again.")
    return safe(u)

# ── Profile ───────────────────────────────────────────────────────────────────
class ProfileUpdate(BaseModel):
    name: Optional[str] = None; bio: Optional[str] = None; college: Optional[str] = None
    degree: Optional[str] = None; gradYear: Optional[str] = None; major: Optional[str] = None
    interests: Optional[str] = None; currentCompany: Optional[str] = None
    currentRole: Optional[str] = None; experience: Optional[str] = None
    linkedin: Optional[str] = None; github: Optional[str] = None

@app.put("/api/users/{uid}/profile")
def update_profile(uid: str, d: ProfileUpdate):
    u = DB["users"].get(uid)
    if not u: raise HTTPException(404, "User not found")
    for k, v in d.model_dump(exclude_none=True).items():
        u[k] = v
    return safe(u)

@app.get("/api/users/{uid}/skills")
def get_skills(uid: str):
    return DB["skills"].get(uid, [])

class SkillData(BaseModel):
    name: str

@app.post("/api/users/{uid}/skills")
def add_skill(uid: str, d: SkillData):
    skills = DB["skills"].get(uid, [])
    if any(s["n"].lower() == d.name.lower() for s in skills):
        raise HTTPException(400, "Skill already added")
    skills.append({"n": d.name, "e": 0})
    DB["skills"][uid] = skills
    u = DB["users"].get(uid)
    if u: u["skills"] = [s["n"] for s in skills]
    return skills

@app.delete("/api/users/{uid}/skills/{idx}")
def del_skill(uid: str, idx: int):
    skills = DB["skills"].get(uid, [])
    if 0 <= idx < len(skills): skills.pop(idx)
    DB["skills"][uid] = skills
    u = DB["users"].get(uid)
    if u: u["skills"] = [s["n"] for s in skills]
    return skills

# ── Mentors ───────────────────────────────────────────────────────────────────
def match_score(student: dict, alumni: dict) -> int:
    sc = norm(student.get("college", "")); ac = norm(alumni.get("college", ""))
    score = 0
    if sc and ac:
        if sc == ac: score += 60
        elif len(sc) > 4 and sc[:5] == ac[:5]: score += 30
    interests = (student.get("interests") or student.get("major") or "").lower().split()
    kw = " ".join([alumni.get("currentRole",""), alumni.get("bio",""), " ".join(alumni.get("skills",[]))]).lower()
    score += min(40, sum(8 for w in interests if len(w) > 2 and w in kw))
    return min(100, score)

@app.get("/api/users/{uid}/mentors")
def get_mentors(uid: str, q: Optional[str] = None):
    student = DB["users"].get(uid)
    if not student: return []
    sc = norm(student.get("college", ""))
    if not sc: return []
    out = []
    for u in DB["users"].values():
        if u["role"] != "alumni" or u["uid"] == uid: continue
        if norm(u.get("college", "")) != sc: continue
        if q:
            s = f"{u.get('name','')} {u.get('currentRole','')} {u.get('currentCompany','')} {' '.join(u.get('skills',[]))}".lower()
            if q.lower() not in s: continue
        out.append({**safe(u), "ms": match_score(student, u)})
    return sorted(out, key=lambda x: x["ms"], reverse=True)

# ── Connections ───────────────────────────────────────────────────────────────
class ReqData(BaseModel):
    to: str

@app.post("/api/users/{uid}/requests")
def send_request(uid: str, d: ReqData):
    fu = DB["users"].get(uid); tu = DB["users"].get(d.to)
    if not fu or not tu: raise HTTPException(404, "User not found")
    if norm(fu.get("college","")) != norm(tu.get("college","")):
        raise HTTPException(400, "You can only connect with alumni from your college")
    if any(r["from"]==uid and r["to"]==d.to and r["status"]=="pending" for r in DB["requests"]):
        raise HTTPException(400, "Request already sent")
    req = {"id": rid(), "from": uid, "to": d.to, "status": "pending", "date": time.strftime("%d/%m/%Y")}
    DB["requests"].append(req)
    return req

@app.put("/api/requests/{req_id}/accept")
def accept_request(req_id: str, uid: str):
    req = next((r for r in DB["requests"] if r["id"] == req_id), None)
    if not req: raise HTTPException(404, "Request not found")
    req["status"] = "accepted"
    already = any((c["a"]==req["from"] and c["b"]==uid) or (c["a"]==uid and c["b"]==req["from"]) for c in DB["connections"])
    if not already: DB["connections"].append({"a": req["from"], "b": uid})
    return req

@app.put("/api/requests/{req_id}/decline")
def decline_request(req_id: str, uid: str):
    req = next((r for r in DB["requests"] if r["id"] == req_id and r["to"] == uid), None)
    if req: req["status"] = "declined"
    return {"ok": True}

@app.delete("/api/requests/{req_id}")
def cancel_request(req_id: str, uid: str):
    DB["requests"] = [r for r in DB["requests"] if not (r["id"] == req_id and r["from"] == uid)]
    return {"ok": True}

@app.get("/api/users/{uid}/connections")
def get_connections(uid: str):
    return [safe(DB["users"][i]) for i in my_conns(uid) if i in DB["users"]]

@app.get("/api/users/{uid}/inbox")
def get_inbox(uid: str):
    u = DB["users"].get(uid)
    if not u: return []
    uc = norm(u.get("college",""))
    out = []
    for r in DB["requests"]:
        if r["to"] != uid: continue
        sender = DB["users"].get(r["from"])
        if sender and norm(sender.get("college","")) == uc:
            out.append({**r, "fromUser": safe(sender)})
    return out

@app.get("/api/users/{uid}/sent")
def get_sent(uid: str):
    return [{**r, "toUser": safe(DB["users"].get(r["to"], {}))} for r in DB["requests"] if r["from"] == uid]

# ── Messages ──────────────────────────────────────────────────────────────────
@app.get("/api/messages/{uid_a}/{uid_b}")
def get_messages(uid_a: str, uid_b: str):
    k1, k2 = f"{uid_a}_{uid_b}", f"{uid_b}_{uid_a}"
    return DB["chats"].get(k1, DB["chats"].get(k2, []))

class MsgData(BaseModel):
    text: str

@app.post("/api/messages/{from_uid}/{to_uid}")
def send_message(from_uid: str, to_uid: str, d: MsgData):
    fu = DB["users"].get(from_uid); tu = DB["users"].get(to_uid)
    if not fu or not tu: raise HTTPException(404, "User not found")
    if norm(fu.get("college","")) != norm(tu.get("college","")):
        raise HTTPException(400, "Same-college messaging only")
    k1, k2 = f"{from_uid}_{to_uid}", f"{to_uid}_{from_uid}"
    key = k2 if k2 in DB["chats"] else k1
    if key not in DB["chats"]: DB["chats"][key] = []
    msg = {"from": from_uid, "text": d.text, "ts": int(time.time() * 1000)}
    DB["chats"][key].append(msg)
    return msg

# ── Jobs ──────────────────────────────────────────────────────────────────────
class JobData(BaseModel):
    title: str; company: str; jobType: str = "Full-time"
    salary: Optional[str] = ""; location: Optional[str] = ""

@app.get("/api/jobs")
def get_jobs(q: Optional[str] = None, type: Optional[str] = None):
    out = []
    for j in DB["jobs"]:
        if q and q.lower() not in f"{j['title']} {j['company']}".lower(): continue
        if type and type != "All" and j.get("jobType") != type: continue
        out.append({**j, "byName": DB["users"].get(j["by"], {}).get("name", "Unknown")})
    return out

@app.post("/api/jobs")
def post_job(uid: str, d: JobData):
    j = {**d.model_dump(), "id": rid(), "by": uid, "date": time.strftime("%d/%m/%Y")}
    DB["jobs"].append(j); return j

# ── Events ────────────────────────────────────────────────────────────────────
class EventData(BaseModel):
    title: str; date: Optional[str] = ""; type: str = "Event"; desc: Optional[str] = ""

@app.get("/api/events")
def get_events():
    return [{**e, "byName": DB["users"].get(e["by"], {}).get("name", "Unknown")} for e in DB["events"]]

@app.post("/api/events")
def create_event(uid: str, d: EventData):
    e = {**d.model_dump(), "id": rid(), "by": uid, "date": time.strftime("%d/%m/%Y")}
    DB["events"].append(e); return e

# ── Forum ─────────────────────────────────────────────────────────────────────
class PostData(BaseModel):
    title: str; content: str; tags: List[str] = []

@app.get("/api/forum")
def get_forum():
    return [{**p, "byName": DB["users"].get(p["by"], {}).get("name", "Anonymous")} for p in reversed(DB["forum"])]

@app.post("/api/forum")
def create_post(uid: str, d: PostData):
    u = DB["users"].get(uid)
    p = {**d.model_dump(), "id": rid(), "by": uid, "byName": u["name"] if u else "?", "likes": 0, "replies": 0, "date": time.strftime("%d/%m/%Y")}
    DB["forum"].append(p); return p

@app.post("/api/forum/{post_id}/like")
def like_post(post_id: str):
    p = next((x for x in DB["forum"] if x["id"] == post_id), None)
    if p: p["likes"] += 1
    return {"ok": True}

# ── Quiz ──────────────────────────────────────────────────────────────────────
QUIZ_ANS = [0, 2, 1, 2, 3, 1, 1, 2, 1, 1]

class QuizSubmit(BaseModel):
    answers: List[int]

@app.post("/api/quiz/{uid}")
def submit_quiz(uid: str, d: QuizSubmit):
    u = DB["users"].get(uid)
    if not u: raise HTTPException(404, "User not found")
    correct = sum(1 for i, a in enumerate(d.answers) if i < len(QUIZ_ANS) and a == QUIZ_ANS[i])
    score = round(correct / len(QUIZ_ANS) * 100)
    earn = 30 if score > 75 else (20 if score == 75 else (10 if score >= 50 else 0))
    u["pts"] = u.get("pts", 0) + earn
    return {"score": score, "correct": correct, "total": len(QUIZ_ANS), "earned": earn, "pts": u["pts"]}

# ── Dashboard ─────────────────────────────────────────────────────────────────
@app.get("/api/dashboard/{uid}")
def get_dashboard(uid: str):
    u = DB["users"].get(uid)
    if not u: raise HTTPException(404, "User not found")
    sc = norm(u.get("college",""))
    conns = my_conns(uid)
    recs = []
    if sc:
        for a in DB["users"].values():
            if a["role"] == "alumni" and a["uid"] != uid and norm(a.get("college","")) == sc:
                recs.append({**safe(a), "ms": match_score(u, a)})
        recs.sort(key=lambda x: x["ms"], reverse=True)
    return {
        "conns": len(conns),
        "pending": sum(1 for r in DB["requests"] if r["from"] == uid and r["status"] == "pending"),
        "skills": len(DB["skills"].get(uid, [])),
        "topM": recs[0]["ms"] if recs else 0,
        "recs": recs[:4],
        "events": DB["events"][-3:],
    }

@app.get("/")
def root():
    return {"status": "AlumniConnect API running", "docs": "/docs"}
